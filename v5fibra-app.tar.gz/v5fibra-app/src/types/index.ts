// ============================================
// V5 Fibra - Tipos do App
// ============================================

export interface Cliente {
  id: string;
  empresa_id: string;
  nome: string;
  cpf: string;
  email: string | null;
  telefone: string | null;
  status: 'ativo' | 'bloqueado' | 'cancelado' | 'suspenso';
  created_at: string;
}

export interface Fatura {
  id: string;
  cliente_id: string;
  empresa_id: string;
  valor: number;
  vencimento: string;
  status: 'pendente' | 'paga' | 'vencida' | 'cancelada';
  metodo: string | null;
  data_pagamento: string | null;
  codigo_barras: string | null;
  pix_copia_cola: string | null;
  pix_qrcode: string | null;
  link_boleto: string | null;
  created_at: string;
}

export interface Contrato {
  id: string;
  cliente_id: string;
  empresa_id: string;
  plano_id: string;
  dia_vencimento: number;
  data_inicio: string;
  data_fim: string | null;
  status: 'ativo' | 'cancelado' | 'suspenso';
  created_at: string;
}

export interface Plano {
  id: string;
  empresa_id: string;
  nome: string;
  velocidade_download: number;
  velocidade_upload: number;
  valor: number;
  descricao: string | null;
  ativo: boolean;
}

export interface TicketAjuda {
  id: string;
  cliente_id: string;
  empresa_id: string;
  titulo: string;
  descricao: string;
  categoria: string;
  status: 'aberto' | 'em_andamento' | 'resolvido' | 'fechado';
  created_at: string;
  updated_at: string;
}

export interface Empresa {
  id: string;
  nome: string;
  logo_url: string | null;
  cor_primaria: string | null;
  cor_secundaria: string | null;
}

// Contrato com plano join
export interface ContratoComPlano extends Contrato {
  plano: Plano;
}

// Sessão do usuário autenticado
export interface UserSession {
  cliente: Cliente;
  empresa: Empresa;
  token: string;
}

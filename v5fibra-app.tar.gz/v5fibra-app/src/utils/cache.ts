// ============================================
// V5 Fibra - Cache Offline com AsyncStorage
// ============================================

import AsyncStorage from '@react-native-async-storage/async-storage';

const CACHE_PREFIX = '@v5fibra_cache:';
const CACHE_EXPIRY_MS = 30 * 60 * 1000; // 30 minutos

interface CacheEntry<T> {
  data: T;
  timestamp: number;
}

export async function getCache<T>(key: string): Promise<T | null> {
  try {
    const raw = await AsyncStorage.getItem(CACHE_PREFIX + key);
    if (!raw) return null;

    const entry: CacheEntry<T> = JSON.parse(raw);
    const isExpired = Date.now() - entry.timestamp > CACHE_EXPIRY_MS;

    // Retorna dados mesmo expirados (modo offline)
    // A UI pode verificar isExpired para mostrar aviso
    return entry.data;
  } catch {
    return null;
  }
}

export async function setCache<T>(key: string, data: T): Promise<void> {
  try {
    const entry: CacheEntry<T> = {
      data,
      timestamp: Date.now(),
    };
    await AsyncStorage.setItem(CACHE_PREFIX + key, JSON.stringify(entry));
  } catch {
    // Silently fail
  }
}

export async function clearCache(): Promise<void> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const cacheKeys = keys.filter((k: string) => k.startsWith(CACHE_PREFIX));
    await Promise.all(cacheKeys.map((k: string) => AsyncStorage.removeItem(k)));
  } catch {
    // Silently fail
  }
}

/**
 * Helper: busca dados com cache offline
 * Tenta buscar do servidor; se falhar, retorna cache
 */
export async function fetchWithCache<T>(
  key: string,
  fetcher: () => Promise<T>
): Promise<{ data: T; fromCache: boolean }> {
  try {
    const freshData = await fetcher();
    await setCache(key, freshData);
    return { data: freshData, fromCache: false };
  } catch {
    const cached = await getCache<T>(key);
    if (cached) {
      return { data: cached, fromCache: true };
    }
    throw new Error('Sem conexão e sem dados em cache');
  }
}

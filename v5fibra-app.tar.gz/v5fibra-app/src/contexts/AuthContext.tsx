// ============================================
// V5 Fibra - Contexto de Autenticação
// ============================================

import React, { createContext, useContext, useEffect, useState } from 'react';
import * as SecureStore from 'expo-secure-store';
import { supabase } from '@/lib/supabase';
import { Cliente, Empresa, UserSession } from '@/types';
import { clearCache } from '@/utils/cache';

interface AuthContextData {
  session: UserSession | null;
  isLoading: boolean;
  signIn: (cpf: string, senha: string) => Promise<void>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextData>({} as AuthContextData);

const SESSION_KEY = '@v5fibra:session';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<UserSession | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Recupera sessão salva ao iniciar
  useEffect(() => {
    loadStoredSession();
  }, []);

  async function loadStoredSession() {
    try {
      const stored = await SecureStore.getItemAsync(SESSION_KEY);
      if (stored) {
        const parsed: UserSession = JSON.parse(stored);
        setSession(parsed);
      }
    } catch {
      // Sessão inválida, ignora
    } finally {
      setIsLoading(false);
    }
  }

  async function signIn(cpf: string, senha: string) {
    // Remove máscara do CPF
    const cpfLimpo = cpf.replace(/\D/g, '');

    // Busca cliente pelo CPF
    const { data: cliente, error: clienteError } = await supabase
      .from('clientes')
      .select('*')
      .eq('cpf', cpfLimpo)
      .single();

    if (clienteError || !cliente) {
      throw new Error('CPF não encontrado');
    }

    // Verifica senha (hash comparado no backend via RPC)
    const { data: authResult, error: authError } = await supabase.rpc(
      'verificar_senha_cliente',
      {
        p_cliente_id: cliente.id,
        p_senha: senha,
      }
    );

    if (authError || !authResult) {
      throw new Error('Senha incorreta');
    }

    // Busca dados da empresa (para white-label)
    const { data: empresa } = await supabase
      .from('empresas')
      .select('id, nome, logo_url, cor_primaria, cor_secundaria')
      .eq('id', cliente.empresa_id)
      .single();

    const userSession: UserSession = {
      cliente: cliente as Cliente,
      empresa: (empresa as Empresa) || {
        id: cliente.empresa_id,
        nome: 'Provedor',
        logo_url: null,
        cor_primaria: null,
        cor_secundaria: null,
      },
      token: `session_${Date.now()}`, // Simplificado; usar JWT real em produção
    };

    await SecureStore.setItemAsync(SESSION_KEY, JSON.stringify(userSession));
    setSession(userSession);
  }

  async function signOut() {
    await SecureStore.deleteItemAsync(SESSION_KEY);
    await clearCache();
    setSession(null);
  }

  return (
    <AuthContext.Provider value={{ session, isLoading, signIn, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser usado dentro de AuthProvider');
  }
  return context;
}

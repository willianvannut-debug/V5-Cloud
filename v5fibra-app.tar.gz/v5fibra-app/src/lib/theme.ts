// ============================================
// V5 Fibra - Tema Dark Mode
// ============================================

export const colors = {
  // Backgrounds
  background: '#0A0A0F',
  card: '#141419',
  cardElevated: '#1C1C24',
  surface: '#22222D',

  // Text
  text: '#FFFFFF',
  textSecondary: '#9CA3AF',
  textMuted: '#6B7280',

  // Brand (padrão, sobrescrito pelo white-label)
  primary: '#6366F1',
  primaryLight: '#818CF8',
  primaryDark: '#4F46E5',

  // Status
  success: '#10B981',
  warning: '#F59E0B',
  danger: '#EF4444',
  info: '#3B82F6',

  // Borders
  border: '#2D2D3A',
  borderLight: '#3D3D4D',

  // Input
  inputBg: '#1C1C24',
  inputBorder: '#2D2D3A',
  inputFocus: '#6366F1',
  placeholder: '#6B7280',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const borderRadius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};

export const fontSize = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 22,
  xxl: 28,
  title: 32,
};

export const fontWeight = {
  regular: '400' as const,
  medium: '500' as const,
  semibold: '600' as const,
  bold: '700' as const,
};
